import { site } from "@/data/site";

const Icon = {
  whatsapp: <path d="M4 3h16a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H10l-5 4v-4H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z" />,
  mail: <path d="M3 5h18a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1Zm1.500 2L12 12.500 19.500 7H4.500Z" />,
  github: <path d="M12 2a10 10 0 0 0-3.200 19.500c.5.100.7-.2.700-.5v-1.800c-2.800.6-3.400-1.200-3.400-1.200-.5-1.100-1.100-1.400-1.100-1.400-.9-.6.100-.6.100-.6 1 .1 1.500 1 1.500 1 .9 1.500 2.300 1.100 2.900.8.100-.7.400-1.100.6-1.300-2.200-.3-4.600-1.100-4.600-5 0-1.100.4-2 1-2.700-.1-.3-.4-1.300.1-2.700 0 0 .8-.3 2.700 1a9.400 9.400 0 0 1 5 0c1.900-1.300 2.700-1 2.700-1 .5 1.400.2 2.400.1 2.700.6.700 1 1.600 1 2.700 0 3.900-2.400 4.700-4.600 5 .4.300.7.900.7 1.900v2.800c0 .3.200.6.700.5A10 10 0 0 0 12 2Z" />,
  linkedin: <path d="M4 3a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM2.500 9h3v12h-3V9Zm5.500 0h2.900v1.700c.5-.9 1.700-1.900 3.500-1.900 3.400 0 4.100 2.200 4.100 5.100V21h-3v-6.300c0-1.500 0-3.300-2-3.300s-2.400 1.600-2.400 3.200V21H8V9Z" />,
};
export const Glyph = ({ name }: { name: keyof typeof Icon }) => <svg aria-hidden viewBox="0 0 24 24" className="h-5 w-5 fill-current">{Icon[name]}</svg>;

const base = "inline-flex items-center justify-center gap-2 rounded-lg px-5 py-3 font-medium transition-colors";

/** Reusable WhatsApp + Email buttons. Pass `message` / `subject` to customise per placement. */
export default function ContactActions({ message = site.greeting, subject = "Project enquiry", className = "" }: { message?: string; subject?: string; className?: string }) {
  const wa = `https://wa.me/${site.whatsapp}?text=${encodeURIComponent(message)}`;
  const mail = `mailto:${site.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(message)}`;
  return (
    <div className={`flex flex-col gap-3 sm:flex-row ${className}`}>
      <a href={wa} target="_blank" rel="noopener noreferrer" className={`${base} bg-em text-ink hover:bg-em-deep`}><Glyph name="whatsapp" />Chat on WhatsApp</a>
      <a href={mail} className={`${base} border border-line hover:border-em hover:text-em`}><Glyph name="mail" />Send an email</a>
    </div>
  );
}
