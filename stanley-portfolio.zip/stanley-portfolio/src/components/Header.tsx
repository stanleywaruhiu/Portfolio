import { site } from "@/data/site";
const links = [["About", "#about"], ["Skills", "#skills"], ["Projects", "#projects"], ["Experience", "#experience"]];
export default function Header() {
  return (
    <header className="sticky top-0 z-20 border-b border-line bg-ink/85 backdrop-blur">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-3">
        <a href="#top" className="font-display text-lg font-semibold">{site.name}</a>
        <nav className="flex items-center gap-6 text-sm text-mute">
          {links.map(([l, h]) => <a key={h} href={h} className="hidden transition-colors hover:text-text sm:block">{l}</a>)}
          <a href="#contact" className="rounded-md border border-line px-3 py-1.5 text-text transition-colors hover:border-em hover:text-em">Get in touch</a>
        </nav>
      </div>
    </header>
  );
}
