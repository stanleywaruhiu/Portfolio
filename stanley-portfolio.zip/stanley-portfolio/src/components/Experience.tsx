import Section from "./Section";
import { experience } from "@/data/site";
export default function Experience() {
  return (
    <Section id="experience" title="Experience & entrepreneurship">
      <ul className="space-y-6 border-l border-line pl-6">
        {experience.map((e) => <li key={e.title}><h3 className="font-display text-lg font-semibold">{e.title}</h3><p className="mt-1 max-w-2xl text-mute">{e.text}</p></li>)}
      </ul>
    </Section>
  );
}
