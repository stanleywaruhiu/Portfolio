import Section from "./Section";
import { skills } from "@/data/site";
export default function Skills() {
  return (
    <Section id="skills" title="Skills">
      <div className="grid gap-4 sm:grid-cols-2">
        {skills.map((g) => (
          <div key={g.group} className="rounded-xl border border-line bg-panel p-5">
            <h3 className="font-display text-lg font-semibold">{g.group}</h3>
            <ul className="mt-3 flex flex-wrap gap-2">{g.items.map((i) => <li key={i} className="rounded-md border border-line px-2.5 py-1 text-sm text-mute">{i}</li>)}</ul>
          </div>
        ))}
      </div>
    </Section>
  );
}
