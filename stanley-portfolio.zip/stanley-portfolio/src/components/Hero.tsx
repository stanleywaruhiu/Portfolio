import { site } from "@/data/site";

// The snippet is the hero's visual: the kind of transaction-safe booking logic behind the hotel system.
const code = `START TRANSACTION;

SELECT id FROM rooms
 WHERE id = :room FOR UPDATE;

-- reject if the dates collide
SELECT COUNT(*) FROM reservations
 WHERE room_id = :room
   AND check_in  < :check_out
   AND check_out > :check_in;

INSERT INTO reservations (...) VALUES (...);
COMMIT;`;

export default function Hero() {
  return (
    <section id="top" className="mx-auto grid max-w-5xl gap-10 px-5 pb-12 pt-14 sm:pt-24 lg:grid-cols-[1.1fr_1fr] lg:items-center">
      <div>
        <h1 className="font-display text-4xl font-semibold leading-[1.08] sm:text-6xl">{site.headline}</h1>
        <p className="mt-5 max-w-xl text-lg text-mute">{site.tagline}</p>
        <p className="mt-3 text-sm text-mute">{site.role}</p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <a href="#projects" className="rounded-lg bg-em px-6 py-3 text-center font-medium text-ink transition-colors hover:bg-em-deep">View My Projects</a>
          <a href="#contact" className="rounded-lg border border-line px-6 py-3 text-center font-medium transition-colors hover:border-em hover:text-em">Get in Touch</a>
        </div>
      </div>
      <figure className="overflow-hidden rounded-xl border border-line bg-panel">
        <figcaption className="border-b border-line px-4 py-2 font-mono text-xs text-mute">reserve_room.sql</figcaption>
        <pre className="overflow-x-auto p-4 font-mono text-[13px] leading-relaxed text-text"><code>{code}</code></pre>
      </figure>
    </section>
  );
}
