import Section from "./Section";
import ContactActions, { Glyph } from "./ContactActions";
import { site } from "@/data/site";
export default function Contact() {
  return (
    <>
      <Section id="contact" title="Let's build something">
        <p className="max-w-xl text-mute">Have a project, a product idea, or a system that needs fixing? Send me a message and I'll reply quickly.</p>
        <ContactActions className="mt-6 max-w-md" />
      </Section>
      <footer className="border-t border-line">
        <div className="mx-auto flex max-w-5xl flex-col items-center justify-between gap-4 px-5 py-6 text-sm text-mute sm:flex-row">
          <p>© {new Date().getFullYear()} {site.name}</p>
          <div className="flex gap-4">
            <a aria-label="GitHub" href={site.github} className="transition-colors hover:text-em"><Glyph name="github" /></a>
            <a aria-label="LinkedIn" href={site.linkedin} className="transition-colors hover:text-em"><Glyph name="linkedin" /></a>
          </div>
        </div>
      </footer>
    </>
  );
}
