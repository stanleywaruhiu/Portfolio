import Section from "./Section";
import { projects } from "@/data/site";
export default function Projects() {
  return (
    <Section id="projects" title="Featured projects">
      <div className="space-y-6">
        {projects.map((p) => (
          <article key={p.title} className="rounded-xl border border-line bg-panel p-6 transition-colors hover:border-em/60">
            <h3 className="font-display text-2xl font-semibold">{p.title}</h3>
            <p className="mt-2 text-mute">{p.summary}</p>
            <div className="mt-5 grid gap-6 md:grid-cols-2">
              <div><h4 className="text-sm font-semibold text-em">The problem</h4><p className="mt-1 text-sm text-mute">{p.problem}</p></div>
              <div><h4 className="text-sm font-semibold text-em">What I built</h4>
                <ul className="mt-1 list-disc space-y-1 pl-5 text-sm text-mute">{p.built.map((b) => <li key={b}>{b}</li>)}</ul></div>
            </div>
            <ul className="mt-5 flex flex-wrap gap-2">{p.stack.map((s) => <li key={s} className="rounded-md bg-ink px-2.5 py-1 font-mono text-xs text-mute">{s}</li>)}</ul>
            {(p.github || p.demo) && <p className="mt-4 flex gap-4 text-sm">{p.demo && <a className="text-em hover:underline" href={p.demo}>Live demo</a>}{p.github && <a className="text-em hover:underline" href={p.github}>Source code</a>}</p>}
          </article>
        ))}
      </div>
    </Section>
  );
}
