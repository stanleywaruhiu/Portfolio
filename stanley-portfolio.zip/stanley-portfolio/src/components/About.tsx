import Image from "next/image";
import Section from "./Section";
import { site, pillars } from "@/data/site";

export default function About() {
  return (
    <Section id="about" title="About me">
      <div className="grid gap-10 md:grid-cols-[280px_1fr] md:items-start">
        <Image
          src="/stanley.jpg" width={900} height={1200} sizes="(min-width: 768px) 280px, 100vw"
          alt="Stanley Waruhiu in a waistcoat, tie and flat cap, holding a laptop bag"
          className="mx-auto w-full max-w-xs rounded-xl border border-line object-cover md:max-w-none"
        />
        <div className="space-y-4 text-mute">{site.about.map((p) => <p key={p}>{p}</p>)}</div>
      </div>
      <dl className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {pillars.map((p) => <div key={p.title} className="rounded-xl border border-line bg-panel p-4"><dt className="font-display font-semibold">{p.title}</dt><dd className="mt-1 text-sm text-mute">{p.text}</dd></div>)}
      </dl>
    </Section>
  );
}
