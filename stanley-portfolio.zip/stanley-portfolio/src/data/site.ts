// Edit this file only: every section of the site reads from it.
export const site = {
  name: "Stanley Waruhiu",
  role: "Full-Stack Software Developer, Project Manager & Technical Entrepreneur",
  headline: "I build the systems behind the business.",
  tagline: "Bridging robust backend architecture, scalable web applications, and real-world business value.",
  url: "https://stanleywaruhiu.dev", // TODO: your real domain
  email: "you@example.com", // TODO
  whatsapp: "254700000000", // TODO: international format, no + or spaces
  github: "https://github.com/your-handle", // TODO
  linkedin: "https://linkedin.com/in/your-handle", // TODO
  greeting: "Hi Stanley, I saw your portfolio and I'd like to talk about a project.",
  about: [
    "I'm a full-stack developer who works across the whole product: database design, PHP and JavaScript application code, secure APIs, and the interface people actually touch.",
    "I also plan and run the work. I break projects into milestones, hold the scope, and keep clients informed through delivery. After launch I stay close to the users, turning their friction and feedback into the next update.",
    "I build practical tech products from scratch, aimed at real bottlenecks that small and mid-sized businesses face every day.",
  ],
};

export const pillars = [
  { title: "Software engineering", text: "Frontend and backend architecture, relational database design, and secure APIs." },
  { title: "Project management", text: "End-to-end lifecycle tracking, milestone execution, and scope control." },
  { title: "User support & operations", text: "Troubleshooting, system reliability, and feedback turned into updates." },
  { title: "Entrepreneurship", text: "Products built from zero to solve real market problems." },
];

export const skills = [
  { group: "Frontend", items: ["HTML5", "CSS3", "JavaScript", "React / Next.js", "Tailwind CSS", "Responsive design"] },
  { group: "Backend & databases", items: ["PHP", "SQL", "MySQL", "REST APIs", "Authentication & validation", "Schema design"] },
  { group: "Project management & Agile", items: ["Milestone planning", "Scope management", "Sprints & backlogs", "Stakeholder updates", "Risk tracking"] },
  { group: "Support & operations", items: ["Troubleshooting", "Ticket triage", "Diagnostic logging", "Documentation", "User training"] },
];

export type Project = { title: string; summary: string; problem: string; built: string[]; stack: string[]; github?: string; demo?: string };
export const projects: Project[] = [
  {
    title: "Computerized Hotel Booking & Management System",
    summary: "A reservation platform that replaces paper registers and phone-call bookings.",
    problem: "Front-desk staff double-handled bookings and lost track of which rooms were free.",
    built: ["Relational schema for guests, rooms, reservations and payments", "Automated room allocation based on dates and room type", "Reservation tracking from booking to checkout", "Administrative support log for every change and complaint"],
    stack: ["PHP", "MySQL", "JavaScript", "HTML/CSS"],
  },
  {
    title: "Scalable Web Application & Startup MVP",
    summary: "A responsive product built to validate a business idea and grow from there.",
    problem: "A new venture needed a working product fast, without a codebase that would need rewriting at the first sign of traction.",
    built: ["Responsive frontend that works on low-end phones", "Business logic separated from presentation so features can be added safely", "Transaction-safe writes so payments and records never end up half-saved"],
    stack: ["JavaScript", "PHP", "SQL", "REST API"],
  },
  {
    title: "IT Support & End-User Assistance Portal",
    summary: "A central help desk where users report problems and staff track them to resolution.",
    problem: "Support requests arrived by call, message and walk-in, so nothing was tracked and the same faults repeated.",
    built: ["Ticket tracking with status, priority and ownership", "Diagnostic logging so recurring faults are visible", "Reporting that shows which issues cost users the most time"],
    stack: ["PHP", "MySQL", "JavaScript"],
  },
];

export const experience = [
  { title: "Technical entrepreneur", text: "Conceive, build and launch practical software products, from the first schema to deployment, and own the outcome." },
  { title: "Project delivery & leadership", text: "Run projects end to end: requirements, milestones, hand-offs and collaboration between developers, clients and users." },
  { title: "End-user support", text: "Resolve user issues, keep systems reliable, and convert client feedback into prioritised updates." },
];
