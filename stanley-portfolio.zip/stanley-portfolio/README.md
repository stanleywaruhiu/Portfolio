# Stanley Waruhiu: Developer Portfolio

Next.js 14 (App Router) + Tailwind CSS. Dark by default, no database, fully static.

## Structure
```
src/data/site.ts           ALL content: name, contacts, about, skills, projects, experience
src/app/layout.tsx         fonts, SEO metadata, Person JSON-LD
src/app/page.tsx           assembles the sections
src/components/
  Header.tsx  Hero.tsx  About.tsx  Skills.tsx  Projects.tsx  Experience.tsx  Contact.tsx
  ContactActions.tsx       reusable WhatsApp + Email buttons
  Section.tsx              shared section wrapper
```

## Run
1. `npm install`
2. Open `src/data/site.ts` and replace every `TODO` (email, WhatsApp number in format `2547XXXXXXXX`, GitHub, LinkedIn, domain).
3. `npm run dev` then open http://localhost:3000

## Deploy (Vercel, free)
Push to GitHub, import the repo at vercel.com, click Deploy. Add your domain under Project Settings > Domains.

## Reuse the contact buttons anywhere
`<ContactActions message="Hi, I'd like a quote for a booking system." subject="Quote request" />`
