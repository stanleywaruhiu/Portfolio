import type { Config } from "tailwindcss";
export default {
  content: ["./src/**/*.{ts,tsx}"],
  theme: { extend: {
    colors: { ink: "#111413", panel: "#181C1A", line: "#2A302D", text: "#E8EDE9", mute: "#8F9993", em: { DEFAULT: "#34D399", deep: "#10B981" } },
    fontFamily: { display: ["var(--font-display)", "sans-serif"], sans: ["var(--font-body)", "system-ui", "sans-serif"], mono: ["var(--font-mono)", "monospace"] },
  } },
} satisfies Config;
